#include "TextBuffer.h"

// ----------------- DoublyLinkedList -----------------

template <typename T>
DoublyLinkedList<T>::DoublyLinkedList() : length(0)
{
    head = new Node(); // dummy head
    tail = new Node(); // dummy tail
    head->next = tail;
    tail->prev = head;
}
// TODO

template <typename T>
void DoublyLinkedList<T>::mergeSort(bool (*cmp)(const T &, const T &))
{
    // TODO
}

template <typename T>
typename DoublyLinkedList<T>::Node *DoublyLinkedList<T>::mergeSortHelper(Node *start, int n, bool (*cmp)(const T &, const T &))
{
    // TODO
}

template <typename T>
typename DoublyLinkedList<T>::Node *DoublyLinkedList<T>::merge(Node *left, int lenL, Node *right, int lenR, bool (*cmp)(const T &, const T &))
{
    // TODO
}

template <typename T>
DoublyLinkedList<T> *DoublyLinkedList<T>::copy() const
{
    // TODO deep copy
}

// ----------------- TextBuffer -----------------
TextBuffer::TextBuffer()
{
    this->cursorPos = 0;
    this->stackUndo = new HistoryManager();
    this->stackRedo = new HistoryManager();
    this->buffer = new DoublyLinkedList<char>();
}

TextBuffer::~TextBuffer()
{
    delete this->stackUndo;
    delete this->stackRedo;
    delete this->buffer;
    this->clearSortUndo();
}

void TextBuffer::insert(char c)
{
    // TODO
}

void TextBuffer::deleteChar()
{
    // TODO
}

void TextBuffer::moveCursorLeft()
{
    if (this->cursorPos <= 0)
        throw cursor_error();
    // TODO
}

void TextBuffer::moveCursorRight()
{
    // TODO
}

void TextBuffer::moveCursorTo(int index)
{
    // TODO
}

string TextBuffer::getContent() const
{
    // TODO foreach
}

int TextBuffer::getCursorPos() const
{
    // TODO
}

int TextBuffer::findFirstOccurrence(char c) const
{
    // TODO foreach
}

int *TextBuffer::findAllOccurrences(char c, int &count) const
{
    // TODO foreach
}

void TextBuffer::deleteAllOccurrences(char c)
{
    // TODO foreach and removeCurrent
}

void TextBuffer::sortAscending()
{
    this->stackUndo->addAction("sort", this->cursorPos, '\0');
    sort_undo.insertAtHead(this->buffer->copy());
    this->buffer->mergeSort(TextBuffer::compareAlphabet);
    this->cursorPos = 0;
}

void TextBuffer::undo()
{
    if (stackUndo->size() > 0)
    {
        HistoryManager::Action action = this->stackUndo->pop();
        this->cursorPos = action.cursorPos;
        // TODO
        this->stackRedo->addAction(action.actionName, action.cursorPos, action.c, action.after_index);
    }
}
void TextBuffer::redo()
{
    if (stackRedo->size() > 0)
    {
        HistoryManager::Action action = this->stackRedo->pop();
        this->cursorPos = action.cursorPos;
        // TODO
    }
}

// ----------------- HistoryManager -----------------
TextBuffer::HistoryManager::HistoryManager() {}

TextBuffer::HistoryManager::~HistoryManager()
{
}

void TextBuffer::HistoryManager::addAction(const string &actionName, int cursorPos, char c, int after_index)
{
    // TODO
}

void TextBuffer::HistoryManager::printHistory() const
{
    // TODO
}

int TextBuffer::HistoryManager::size() const
{
    // TODO
}

TextBuffer::HistoryManager::Action TextBuffer::HistoryManager::pop()
{
    // TODO
}

TextBuffer::HistoryManager::Action TextBuffer::HistoryManager::top()
{
    if (actions.size() == 0)
        return {"", 0, '\0'};
    return actions.get(0);
}

void TextBuffer::HistoryManager::clear()
{
    for (auto it = actions.begin(); it != actions.end(); ++it)
        it.removeCurrent(&actions);
}

// Explicit template instantiation for char, string, int, double, float, and Point
template class DoublyLinkedList<char>;
template class DoublyLinkedList<string>;
template class DoublyLinkedList<int>;
template class DoublyLinkedList<double>;
template class DoublyLinkedList<float>;
template class DoublyLinkedList<Point>;
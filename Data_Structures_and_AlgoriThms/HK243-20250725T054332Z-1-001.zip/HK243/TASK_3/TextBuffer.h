#ifndef __TEXT_BUFFER_H__
#define __TEXT_BUFFER_H__

#include "main.h"

template <typename T>
class DoublyLinkedList
{
    // TODO: may provide some attributes
private:
    struct Node
    {
        T data;
        Node *prev;
        Node *next;
        Node() : prev(nullptr), next(nullptr) {}
        Node(const T &val, Node *prev = nullptr, Node *next = nullptr) : data(val), prev(prev), next(next) {}
    };

    Node *head; // Dummy head
    Node *tail; // Dummy tail
    int length;

public:
    DoublyLinkedList();
    ~DoublyLinkedList();

    void insertAtHead(T data);
    void insertAtTail(T data);
    void insertAt(int index, T data);
    void deleteAt(int index);
    T &get(int index) const;
    int indexOf(T item) const;
    bool contains(T item) const;
    int size() const;
    void reverse();
    string toString(string (*convert2str)(T &) = 0) const;

    void mergeSort(bool (*cmp)(const T &, const T &));
    Node *mergeSortHelper(Node *start, int n, bool (*cmp)(const T &, const T &));
    Node *merge(Node *left, int lenL, Node *right, int lenR, bool (*cmp)(const T &, const T &));
    DoublyLinkedList<T> *copy() const;

    class Iterator
    {
    private:
        Node *current;

    public:
        Iterator(Node *node) : current(node) {}

        T &operator*() const
        {
            return current->data;
        }

        Iterator &operator++()
        {
            current = current->next;
            return *this;
        }

        Iterator &operator--()
        {
            current = current->prev;
            return *this;
        }

        void removeCurrent(DoublyLinkedList<T> *list)
        {
            Node *nodeToDelete = current;
            Node *prev = current->prev;
            Node *next = current->next;

            prev->next = next;
            next->prev = prev;

            current = prev;
            delete nodeToDelete;
            list->length--;
        }

        bool operator==(const Iterator &other) const
        {
            return current == other.current;
        }

        bool operator!=(const Iterator &other) const
        {
            return current != other.current;
        }
    };

    Iterator begin() const
    {
        return Iterator(head->next);
    }

    Iterator end() const
    {
        return Iterator(tail);
    }
};

class TextBuffer
{
public:
    class HistoryManager;

private:
    DoublyLinkedList<char> *buffer;
    int cursorPos;

    // TODO: may provide some attributes
    HistoryManager *stackUndo, *stackRedo;
    DoublyLinkedList<DoublyLinkedList<char> *> sort_undo;

    void clearSortUndo()
    {
        for (auto it = sort_undo.begin(); it != sort_undo.end(); ++it)
        {
            delete *it;
            it.removeCurrent(&sort_undo);
        }
    }
    static bool compareAlphabet(const char &a, const char &b)
    {
        if (tolower(a) == tolower(b))
            return a < b;
        return tolower(a) < tolower(b);
    }

public:
    TextBuffer();
    ~TextBuffer();

    void insert(char c);
    void deleteChar();
    void moveCursorLeft();
    void moveCursorRight();
    void moveCursorTo(int index);
    string getContent() const;
    int getCursorPos() const;
    int findFirstOccurrence(char c) const;
    int *findAllOccurrences(char c, int &count) const;
    void sortAscending();
    void deleteAllOccurrences(char c);
    void undo();
    void redo();

public:
    class HistoryManager
    {
        struct Action
        {
            string actionName;
            int cursorPos;
            char c;
            int after_index; //! khi dùng hàm cursorPos index thì gặp vấn đề là khi redo không biết cần index tới vị trí nào -> nên dùng này lưu
        };
        DoublyLinkedList<Action> actions;
        friend class TextBuffer;

    public:
        HistoryManager();
        ~HistoryManager();

        void addAction(const string &actionName, int cursorPos, char c, int after_index = 0);
        void printHistory() const;
        int size() const;

        // lấy ra phần tử đầu vào xóa nó
        Action pop();
        // lấy ra phần tử đầu
        Action top();
        // clear tất cả các phần tử trong action
        void clear();
    };
};

#endif // __TEXT_BUFFER_H__

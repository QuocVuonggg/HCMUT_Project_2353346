`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 12/11/2025 12:47:06 PM
// Design Name: 
// Module Name: process_tb_assignment
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module process_tb_assignment;
// 1. Khai b�o t�n hi?u
    reg clk;
    reg rst;
    
    // C�c t�n hi?u output t? Processor ?? quan s�t
    wire halt;
    wire [31:0] trace_writeback_pc;
    wire [31:0] trace_writeback_inst;

    // 2. Instance module Processor (Top-level c?a Lab 5)
    // L?u �: T�n module ph?i kh?p v?i file DatapathPipelined.v
    Processor uut (
        .clk(clk),
        .rst(rst),
        .halt(halt),
        .trace_writeback_pc(trace_writeback_pc),
        .trace_writeback_inst(trace_writeback_inst)
    );

    // 3. T?o xung Clock
    // Chu k? 10ns (T?n s? 100MHz), ??o tr?ng th�i m?i 5ns
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // 4. Quy tr�nh Reset v� Ki?m tra
    initial begin
        // Kh?i t?o
        rst = 1;
        
        // Gi? Reset trong 20ns (2 chu k? clock)
        #20;
        
        // Th? Reset (Active Low ho?c High t�y thi?t k?, ? ?�y Lab d�ng Active High cho rst)
        rst = 0;
        
        // Ch? ??i m� ph?ng ch?y
        $display("-------------------------------------------------------------");
        $display("Simulation Started...");
        $display("Time\t\tPC Writeback\tInstruction\tHalt");
        $display("-------------------------------------------------------------");
    end

    // 5. Monitor: In k?t qu? ra Console m?i khi c� xung clock d??ng
    always @(posedge clk) begin
        if (!rst) begin
            $display("%0t\t\t%h\t\t%h\t\t%b", $time, trace_writeback_pc, trace_writeback_inst, halt);
            
            // N?u CPU b�o Halt th� d?ng m� ph?ng sau m?t ch�t
            if (halt) begin
                $display("-------------------------------------------------------------");
                $display("HALT signal detected. Simulation finished successfully.");
                #50; // Ch?y th�m v�i cycle ?? nh�n r� waveform
                $finish;
            end
        end
    end

    // 6. Timeout: Ph�ng tr??ng h?p CPU b? treo (v�ng l?p v� h?n kh�ng c� ecall)
    initial begin
        #50000; // Ch?y t?i ?a 50,000ns (t�y ch?nh n?u ch??ng tr�nh d�i)
        $display("-------------------------------------------------------------");
        $display("TIMEOUT: Simulation force stopped (Run too long).");
        $finish;
    end
endmodule
